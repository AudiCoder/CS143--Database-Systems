CS 143 Database Systems: Fall 2014 

Project 2 (Part D)


***We Have used remaining 2 Grace Days***

Team members:


1)	Name : Akshit Chopra
	
	UID  : 604414277
	
	Email: akshit.chopra@cs.ucla.edu


2)	Name : Ankush Verma
	
	UID  : 904435669 
	
	Email: ankushverma@cs.ucla.edu






